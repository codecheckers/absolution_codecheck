#' The application User-Interface
#'
#' @param request Internal parameter for `{shiny}`.
#'     DO NOT REMOVE.
#' @import shiny
#' @import DT
#' @import shinyWidgets
#' @import fresh
#' @import plotly
#' @import shinycssloaders
#' @import shinyFiles
#' @import shinyjs
#' @import shinymanager
#' @import shinythemes
#' @import shinyWidgets
#' @import upsetjs
#' @import utils
#' @import shinymeta
#' @import bs4Dash
#' @noRd
app_ui <- function(request) {
    shiny::tagList(
        golem_add_external_resources(),
        bs4Dash::bs4DashPage(
          freshTheme =fresh::create_theme(
            bs4dash_vars(
              body_bg = "#264653",
              navbar_light_color = "#2a9d8f",
              navbar_light_active_color = "#f4a261",
              navbar_light_hover_color = "#e76f51"
            ),

            bs4dash_yiq(
              contrasted_threshold = 10,
              text_dark = "#f8f9fa",
              text_light = "#272c30"
            ),
            bs4dash_layout(
              main_bg = "#f8f9fa"
            ),
            bs4dash_sidebar_light(
              bg = "#264653",
              color = "#f8f9fa",
              hover_color = "#2a9d8f",
              submenu_bg = "#264653",
              submenu_color = "#f8f9fa",
              submenu_hover_color = "#2a9d8f"
            ),
            bs4dash_status(
              primary = "#264653", danger = "#e76f51", light = "#f8f9fa",
              secondary = "#2a9d8f", warning="#f4a261"
            ),
            bs4dash_color(
              gray_900 = "#272c30", white = "#f8f9fa"
            ),
            bs4dash_button(
              default_background_color = "#2a9d8f",
              default_color="#f8f9fa"
            )
          ),
          header= bs4DashNavbar(
              title=bs4DashBrand(title="Solution", color = "primary",
                                 image = "www/favicon.png", opacity = 1),
              leftUi = tagList(
                bs4Dash::dropdownMenu(
                  badgeStatus = "info",
                  type = "tasks",
                  bs4Dash::taskItem(
                    inputId = "triggerAction3",
                    text = "My progress",
                    color = "orange",
                    value = 10
                  )
                )
              ),
              controlbarIcon = icon("circle-plus"),
              rightUi = bs4Dash::dropdownMenu(
                badgeStatus = "danger",
                type = "messages",
                bs4Dash::messageItem(
                  inputId = "triggerAction1",
                  message = "Have fun, AbSolutely! Do not forget to check the Help tab on each step",
                  from = "Rodrigo García",
                  image = "www/img/Rodrigo.jpg",
                  time = "today",
                  color = "lime"
                )
              )
            ),
            sidebar =bs4DashSidebar(
              skin = "light",
              bs4SidebarMenu(
                  id = "sidebar",
                  bs4SidebarMenuItem("Home",
                           tabName = "home",
                           icon = ionicon(name ="home"),
                           selected=T),
                  bs4SidebarMenuItem(
                    "AbSolution",
                    icon =  ionicon(name ="analytics"),
                    tabName = "pipeline"
                ),
                bs4SidebarMenuItem(
                    "About us", icon = ionicon(name ="information-circle"),
                    tabName = "About"
                )
              )
            ),
          body =bs4DashBody(
                useShinyjs(),
                tags$head(tags$link(rel = "shortcut icon",
                                    href = "www/img/favicon.ico")),
                tags$style(HTML(".fade:not(.show) {  opacity: 1; !important}")),
                # shinyDashboardThemes(theme = "poor_mans_flatly"),
                bs4TabItems(
                  tabItem(
                    tabName = "home", fluidRow(
                      userBox(
                        title = NULL, type = 2, src = NULL, color = "yellow", width = 12,
                        boxToolSize = "lg", closable = F, collapsible = F, uiOutput("AbLogo"),
                        footer = HTML(
                          "<b>A tool for antibody Fab sequence feature analysis</b>
                    <br>
                    <p align='justify'>AbSolution is a fancy pipeline. <br><br>Contact: <a href='mailto:r.garciavaliente@amsterdamumc.nl'> Biolab</a>
                                  </p>
                                  "
                      ),
                    HTML("<br><br>"),
                    textInput("username", "User name", "User", width="30%"),
                    textInput("usermail", "Contact email", "Email", width="30%")
                    )
                  )
                ),
                  tabItem(
                    tabName = "pipeline", h2("Process your data"),
                    HTML(
                      "If you have previous files, you don't have to redo all the steps. Process and upload your files where/when needed. But do provide the sample information.<br> <br>"
                  ),
                  bs4Dash::tabBox(id = "menutabset", width=12, collapsible = F,

                      # 0.Project information  ######
                      tabPanel(
                        "0.Project information",
                          wellPanel(
                            fluidRow(
                            column(9,
                                   textAreaInput("user_0_comments",
                                                 "User comments",
                                                 "",
                                                 width = "30%"),
                            h3("Upload your sample information table"),
                            tooltip(
                              radioButtons(
                                inputId="TCRBCR_input_file",
                                label="The repertoire to analyze is:",
                                choiceNames = list("BCR", "TCR"),
                                choiceValues = list("BCR", "TCR"),
                                selected = "BCR"
                              ),
                              title = "TCR and BCR repertoires should be analyzed separatedly.",
                              placement = "bottom"
                            ) ,
                            tooltip(radioButtons(
                              inputId="radiobutton_input_file",
                              label= "The input file type is:",
                              choiceNames = list("AIRR-Seq format"),
                              choiceValues = list("airrseq"),
                              selected = "airrseq"
                               ),
                              title = "Data should follow the AIRR-Seq format https://docs.airr-community.org/en/latest/datarep/rearrangements.html",
                              placement = "top"
                            ),
                            uiOutput("Conditional_Action_Filetype_description"),
                            uiOutput("Conditional_Action_Filetype_upload"),

                            HTML("<br>"),
                            DT::dataTableOutput("raw_sample_file_out"),
                            HTML("<br><br><h3>Select work folder</h3>"),

                           shinyDirButton(
                              id="base_folder",
                              label="Select the folder where the data will be saved",
                              title = "Please select the work folder:", buttonType = "default",
                              class = NULL, icon = icon("folder", lib = "font-awesome"),
                              multiple = F
                              ),
                            HTML("<br><br><br><h3>Next step</h3>"),
                            uiOutput("Conditional_Action_Move_to_1"),
                            HTML("<br><br>"),
                            uiOutput("Conditional_Action_Move_to_Analysis")
                        ),
                          column(3,
                                 HTML("<br><br>"),
                                 uiOutput("Demo_Analysis")
                          )
                        )
                      )
                      ),
                      # 1.AIRR-Seq conversion  ######
                      tabPanel(
                        "1.AIRR-Seq conversion", wellPanel(
                          h3("Upload your AIRR-Seq  files"),
                          HTML("Select the main folder that contains the different AIRR-Seq files.<br> <br>"),
                          shinyDirButton(
                            "preinfolder_AIRR", "Select main folder", title = "Please select the main folder:",
                            buttonType = "default", class = NULL, icon = icon("folder", lib = "font-awesome"),
                            multiple = F
                          ),
                          HTML("<br>"),
                          DT::dataTableOutput("folder_information_AIRR"),
                          HTML("<br>"),
                          h3("Set parameters for germline reconstruction"),
                          materialSwitch(
                            inputId="Dgene_reconstruct_airr",
                            label=tags$span("Reconstruct using the D gene information instead of keeping that part of the CDR3 as is.",
                                            shinyBS::bsButton("info_Dgene_reconstruct_airr",
                                                              label = "",
                                                              icon = icon("info"),
                                                              style = "info",
                                                              size = "extra-small")
                            ),
                            value = T
                          ),
                          shinyBS::bsPopover(
                            id = "info_Dgene_reconstruct_airr",
                            title = "More information",
                            content = paste0(
                              "D genes, located in the CDR3, are of short length",
                              " and due to NPJ additions they are",
                              " hard to idenfity. You can decide to reconstruct it",
                              " using the inferred D germline and NPJs ",
                              " or keep the fragment of the sequence as they appear",
                              " in the repertoire"
                            ),
                            placement = "right",
                            trigger = "click",
                            options = list(container = "body")
                          ),
                          materialSwitch(
                            inputId="FWR1partial_airr",
                            label= tags$span("Is there a partial FWR1 in the sequences?",
                                             shinyBS::bsButton("info_PartialFWR1",
                                                               label = "",
                                                               icon = icon("info"),
                                                               style = "info",
                                                               size = "extra-small")
                            ),
                            value = FALSE
                          ),
                          shinyBS::bsPopover(
                            id = "info_PartialFWR1",
                            title = "More information",
                            content = paste0(
                              "Depending on the primer location, sometimes the BCR",
                              "/TCR sequence is not fully sequenced. If this ",
                              "happens, AbSolution may be biased as not all ",
                              "sequences will have the same starting point. ",
                              "Activate this option if the FWR1 is not fully sequenced",
                              ". The FWR1 will be removed from the analysis"
                            ),
                            placement = "right",
                            trigger = "click",
                            options = list(container = "body")
                          ),
                          materialSwitch(
                            inputId="FWR4partial_airr",
                            label=tags$span("Is there a partial FWR4 in the sequences?",
                                            shinyBS::bsButton("info_PartialFWR4",
                                                              label = "",
                                                              icon = icon("info"),
                                                              style = "info",
                                                              size = "extra-small")
                            ),
                            value = FALSE
                          ),
                          shinyBS::bsPopover(
                            id = "info_PartialFWR4",
                            title = "More information",
                            content = paste0(
                              "Depending on the primer location, sometimes the BCR",
                              "/TCR sequence is not fully sequenced. If this ",
                              "happens, AbSolution may be biased as not all ",
                              "sequences will have the same ending point. ",
                              "Activate this option if the FWR4 is not fully sequenced.",
                              " The FWR4 will be removed from the analysis."
                            ),
                            placement = "right",
                            trigger = "click",
                            options = list(container = "body")
                          ),
                          materialSwitch(
                            inputId="C_region_included_airr",
                            label=tags$span("Is part or totatily of the pre-FWR1 or the C region included in the sequence?",
                                            shinyBS::bsButton("info_Cgene",
                                                              label = "",
                                                              icon = icon("info"),
                                                              style = "info",
                                                              size = "extra-small")
                            ),
                            value = FALSE
                          ),
                          shinyBS::bsPopover(
                            id = "info_Cgene",
                            title = "More information",
                            content = paste0(
                              "Depending on the primer location, sometimes the BCR",
                              "/TCR sequence pre-FWR1 or C region (or UMIs) are included in the",
                              "sequence. If this  happens, AbSolution may be biased",
                              " due to the sequence extra composition",
                              "Activate this option if the preFWR1/C gene/UMIs are present. ",
                              "The FWR4 will be removed from the analysis."
                            ),
                            placement = "right",
                            trigger = "click",
                            options = list(container = "body")
                          ),
                          HTML("<br>"),
                          DT::dataTableOutput("DT_example_parsed_sequence"),
                          HTML("<br>"),
                          h3("Process AIRR-Seq files and continue to the next step"),
                          HTML("<br>"),
                          uiOutput("Conditional_Action_Preprocess_AIRR"),
                          shinyjs::hidden(
                            div(
                              id = "pb_AIRR_vis", shinyWidgets::progressBar(
                                id = "pb_AIRR", value = 0, total = 100, title = "Processing...",
                                display_pct = TRUE
                              )
                            )
                          ),
                          textAreaInput("user_1_comments",
                                        "User comments",
                                        "",
                                        width = "30%"),
                          uiOutput("Conditional_Action_Move_to_2_AIRR")
                        )
                      ),
                      # 2.Sequence feature determination  ######
                      tabPanel(
                        "2.Sequence feature determination", wellPanel(
                          actionButton(
                            "Feature_determination", "Feature determination", icon("forward"),
                            style = "color: #fff; background-color: #18bc9c"
                          ),
                          div(
                            id = "pb_Feature_vis", shinyWidgets::progressBar(
                              id = "pb_Feature", value = 0, total = 100, title = "Processing...",
                              display_pct = TRUE
                            )
                          ),
                          textAreaInput("user_2_comments",
                                        "User comments",
                                        "",
                                        width = "30%"),
                          HTML("<br><br><br>"),
                          uiOutput("make_dummy_2"),
                          conditionalPanel(
                            "input.dummy_dataset == true", selectizeInput(
                              "make_dummy_menu", "Make a dummy version of the dataset:",
                              choices = NULL, multiple = F, options = list(plugins = list("remove_button"))
                            )
                          ),
                          conditionalPanel(
                            "input.make_dummy_menu.length > 0 & input.dummy_dataset == true",
                            numericInput(
                              "dummy_ratio", "How many sequences per original sequence?",
                              1, min = 1, max = 10
                            ),
                            actionButton(
                              "final_dummy",
                              "Produce the dummy dataset (click and wait until the table refreshes)",
                              icon("forward"),
                              style = "color: #fff; background-color: #18bc9c"
                            )
                          ),
                          uiOutput("Conditional_Action_Move_to_3")
                        )
                      ),
                      # 1&2. Select your FBM and associated files  ######
                      tabPanel(
                        "Page 1&2. Select your FBM and associated files", wellPanel(
                          shinyDirButton(
                            "FBM_folder", "Select the folder with your .rds and .bk files",
                            title = "Please select the bigmem folder:", buttonType = "default",
                            class = NULL, icon = icon("folder", lib = "font-awesome"),
                            multiple = F
                          ),
                          HTML("<br>"),
                          DT::dataTableOutput("folder_information_AIRR_steps_1_to_3"),
                          HTML("<br><br><br>"),
                          uiOutput("make_dummy"),
                          conditionalPanel(
                            "input.dummy_dataset == true", selectizeInput(
                              "make_dummy_menu", "Make a dummy version of the dataset:",
                              choices = NULL, multiple = F, options = list(plugins = list("remove_button"))
                            )
                          ),
                          conditionalPanel(
                            "input.make_dummy_menu.length > 0 & input.dummy_dataset == true",
                            numericInput(
                              "dummy_ratio", "How many sequences per original sequence?",
                              1, min = 1, max = 10
                            ),
                            actionButton(
                              "final_dummy",
                              "Produce the dummy dataset (click and wait until the table refreshes)",
                              icon("forward"),
                              style = "color: #fff; background-color: #18bc9c"
                            )
                          ),
                          HTML("<br><br><br>"),
                          uiOutput("Conditional_Action_Move_to_Analysis_Real")
                        )
                      ),
                      # 3.Dataset exploration and variable selection ######
                      tabPanel(
                        "3.Dataset exploration and variable selection",
                        bs4Dash::tabBox(id = "3menu", width=12, collapsible = F,
                          tabPanel(
                            "Menu", fluidRow(column(
                              4, wellPanel(
                                HTML(
                                  "Explore the dataset using both plots. The dataset and variables that you will use for the feature selection process are represented in the Selection plot. <br>"
                                ),
                                h3("1. Select your sequences"),
                                selectizeInput(
                                  inputId="use_what",
                                  label = tags$span("Include sequences:",
                                                    shinyBS::bsButton("info_sequences_included",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c("Repertoire", "Reconstructed germline"),
                                  selected = c("Repertoire"),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_sequences_included",
                                  title = "More information",
                                  content = "Work the sequenced sequences (repertoire) and/or their inferred germlines.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                selectizeInput(
                                  inputId="use_productive_or_not",
                                  label = tags$span("That are:",
                                                    shinyBS::bsButton("info_productive_or_not",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c("Productive"),
                                  selected = c("Productive"),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_productive_or_not",
                                  title = "More information",
                                  content = "Use productive and/or non-productive sequences. Currently only productive sequences are supported.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                uiOutput("Sample_selection"),
                                uiOutput("Chain_selection"),
                                uiOutput("Type_selection"),
                                sliderInput(
                                  inputId = "Rmut_filter",
                                  label = tags$span("Include only sequences with a number of R mutations between",
                                                    shinyBS::bsButton("info_mutation_thresholds",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  min = 0, max = 100, value = c(0, 100),
                                  step = 1
                                ),
                                shinyBS::bsPopover(
                                  id = "info_mutation_thresholds",
                                  title = "More information",
                                  content = "Select minimum and maximum number of R mutations. This allows to e.g. filter naïve sequences or outliers.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                uiOutput("VJ_selection"),
                                HTML("<br>"),
                                h3("2. Select your variables"),
                                HTML(
                                  "<i>NOTE: Variables with NAs/Infinite/Zero variance are automatically removed.</i><br><br>"
                                ),
                                selectizeInput(
                                  inputId="my_regions",
                                  label = tags$span("Select the region(s)",
                                                    shinyBS::bsButton("info_regions_to_use",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c(
                                    "Whole", "FWR1", "CDR1", "FWR2", "CDR2", "FWR3",
                                    "CDR3", "FWR4"
                                  ),
                                  selected = c("CDR3"),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_regions_to_use",
                                  title = "More information",
                                  content = "Select which regions (and/or the whole Fab sequence) to include in the analysis.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                selectizeInput(
                                  inputId="my_var_elements",
                                  label = tags$span("Study features from",
                                                    shinyBS::bsButton("info_var_elements_to_use",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c("NT", "AA"),
                                  selected = c("NT", "AA"),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_var_elements_to_use",
                                  title = "More information",
                                  content = "Work with features calculated according to the AA and/or NT sequences",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                selectizeInput(
                                  inputId="my_vars",
                                  label = tags$span("Select the variable(s) class(es)",
                                                    shinyBS::bsButton("info_my_vars_to_use",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c(
                                    "Length", "Composition", "NGly sites", "Hot/Cold motifs",
                                    "Insertions",
                                    "Deletions", "Transitions and transversions",
                                    "Replacement and silent mutations", "Mutations from X to Y",
                                    "Peptide features"
                                  ),
                                  selected = c(
                                    "Length", "Composition", "NGly sites", "Hot/Cold motifs",
                                    "Peptide features"
                                  ),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_my_vars_to_use",
                                  title = "More information",
                                  content = "Select or unselect groups of variables to include in the analysis.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                selectizeInput(
                                  inputId="my_vartypes",
                                  label = tags$span("Select the variable type(s)",
                                                    shinyBS::bsButton("info_my_vartypes_to_use",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  choices = c("Baseline", "Germline diff"),
                                  selected = c("Baseline"),
                                  multiple = TRUE, options = list(plugins = list("remove_button"))
                                ),
                                shinyBS::bsPopover(
                                  id = "info_my_vartypes_to_use",
                                  title = "More information",
                                  content = "Include variables measured at the sequence and/or its difference between the sequence and its germline.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                uiOutput("individual_variables"),
                                materialSwitch(
                                  inputId="use_UMAP",
                                  label = tags$span("Also represent the data in a UMAP (increases computational time)",
                                                    shinyBS::bsButton("info_UMAP",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  value = FALSE, width = NULL, status = "primary"
                                ),
                                shinyBS::bsPopover(
                                  id = "info_UMAP",
                                  title = "More information",
                                  content = "The UMAP will only be calculated if the data fits the RAM memory.",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                HTML("<br>"),
                                h3("3. Define the groups to study"),
                                materialSwitch(
                                  inputId="work_as_categories",
                                  label = tags$span("I want to compare between groups",
                                                    shinyBS::bsButton("info_work_as_categories",
                                                                      label = "",
                                                                      icon = icon("info"),
                                                                      style = "info",
                                                                      size = "extra-small")
                                  ),
                                  value = FALSE, width = NULL, status = "primary"
                                ),
                                shinyBS::bsPopover(
                                  id = "info_work_as_categories",
                                  title = "More information",
                                  content = "Do you want to work only with certain groups of interest?",
                                  placement = "right",
                                  trigger = "click",
                                  options = list(container = "body")
                                ),
                                uiOutput("Group_selection"),
                                uiOutput("Group_comparison"),
                                hr(),
                                materialSwitch(
                                  inputId="use_sharedVDJ",
                                  label = "Include only sequences with VJ genes present in all the groups",
                                  value = FALSE, width = NULL, status = "primary"
                                ),
                                materialSwitch(
                                  inputId="VDJ_normalized_per_size",
                                  label = "Use the same number of sequences for each VJ combination on each group",
                                  value = T, width = NULL, status = "primary"
                                ),
                                materialSwitch(
                                  inputId="VDJ_maximize_clones",
                                  label = "Maximize the number of clones for each VJ combination on each group",
                                  value = T, width = NULL, status = "primary"
                                ),
                                selectizeInput(
                                  inputId="my_clone_def",
                                  label = "Select the clone definition",
                                  choices = c(NULL),
                                  selected = c(NULL),
                                  multiple = F, options = list(plugins = list("remove_button"))
                                ),
                                materialSwitch(
                                  inputId="VDJ_normalized_per_sample",
                                  label = "And apply these rules also to each individual sample",
                                  value = F, width = NULL, status = "primary"
                                ),
                                uiOutput("VDJ_subsetting"),
                                materialSwitch(
                                  inputId="use_univlog",
                                  label = "Include only features that are correlated to the groups (0/1)" ,
                                  value = FALSE, width = NULL, status = "primary"
                                ),
                                selectizeInput(
                                  inputId="pval_type",
                                  label = "Select the P-value to use" ,
                                  choices = c("RAW", "Corrected by Bonferroni", "Corrected by B-H"),
                                  selected = c("Corrected by Bonferroni"),
                                  multiple = F, options = list(plugins = list("remove_button"))
                                ),
                                numericInput(
                                  inputId="pval_cutoff",
                                  label = "P-value cut-off (<=):", 0.05,
                                  min = 0, max = 1
                                ),
                                numericInput(
                                  inputId="estimate_cutoff",
                                  label = "Estimate cut-off (absolute value, <=):",
                                  2, min = 0
                                ),
                                selectizeInput(
                                  inputId="number_selected_vars",
                                  label = "How many selected features to use?",
                                  choices = c(
                                    "All", "Top 10 (according to estimate)",
                                    "Top 50 (according to estimate)"
                                  ),
                                  selected = c("All"),
                                  multiple = F, options = list(plugins = list("remove_button"))
                                ),
                                h3("4. Update your changes"),
                                actionButton(
                                  "Update_selection", "Update Selection set, used for all the analyses",
                                  icon("forward"),
                                  style = "color: #fff; background-color: #18bc9c"
                                ),
                                actionButton(
                                  "Update_exploration", "Update Exploration set, to compare with Selection",
                                  icon("forward"),
                                  style = "color: #fff; background-color: #CC2936"
                                )
                              )
                            ),
                            column(
                              8, HTML("<br><br>"),
                              HTML("Use the lasso tool or box select to get the sequence(s) information.<br><br>"),
                              fluidRow(
                                column(
                                  4, HTML("<h2>Selection plot</h2>"),
                                  fluidRow(
                                    column(
                                      6, selectInput(
                                        inputId="Selection_plot_type",
                                        label = "Dimensionality Reduction:",
                                        c(PCA = "PCA")
                                      ),
                                      selectizeInput(
                                        inputId="Selection_plot_type_dim",
                                        label = "Select the (1 to 5) dimensions to plot",
                                        choices = c(1:5),
                                        selected = c(1, 2),
                                        multiple = TRUE, options = list(
                                          plugins = list("remove_button"),
                                          maxItems = 2
                                        )
                                      ),
                                      uiOutput("Plot_color")
                                    )
                                  )
                                ),
                                column(8, plotlyOutput("Selection_plot")%>%
                                         withSpinner(type = 6, color = "#cf395c"))
                              ),
                              fluidRow(
                                column(
                                  4, HTML("<h2>Exploration plot</h2>"),
                                  fluidRow(
                                    column(
                                      6, selectInput(
                                        inputId="Exploration_plot_type",
                                        label = "Dimensionality Reduction:",
                                        c(PCA = "PCA")
                                      ),
                                      selectizeInput(
                                        inputId="Exploration_plot_type_dim",
                                        label ="Select the (1 to 5) dimensions to plot",
                                        choices = c(1:5),
                                        selected = c(1, 2),
                                        multiple = TRUE, options = list(
                                          plugins = list("remove_button"),
                                          maxItems = 2
                                        )
                                      ),
                                      uiOutput("Plot_color_expl")
                                    )
                                  )
                                ),
                                column(8, plotlyOutput("Exploration_plot")%>%
                                         withSpinner(type = 6, color = "#cf395c"))
                              ),
                              fluidRow(
                                column(6, uiOutput("Selection_plot_error")),
                                column(6, uiOutput("Exploration_plot_error"))
                              ),
                              fluidRow(
                                column(6, infoBoxOutput("RAM_S_Memory_Box", width = 12)),
                                column(6, infoBoxOutput("RAM_E_Memory_Box", width = 12))
                              ),
                              textAreaInput("user_3_comments",
                                            "User comments",
                                            "",
                                            width = "30%"),
                              DT::dataTableOutput("Ab_table")
                            ))
                          ),
                          tabPanel(
                            "About the variables", uiOutput("about_vars"),
                            bs4Dash::tabBox(id = "varmenu", width=12, collapsible = F,
                              tabPanel(
                                "Used variables", fluidRow(
                                  column(
                                    10, HTML(
                                      "<br>Here you can see which variables are represented on each set.<br><br>The plots can take a few minutes to load!<br><br>"
                                    ),
                                    HTML("<h2>Selection set</h2>"),
                                    HTML("<h3>Whole sequence</h3>")
                                  )
                                )
                              ),
                              tabPanel(
                                "Variable correlation", HTML(
                                  "<br>Here you can see which variables in the selection set are correlated >=0.8 for their non-zero values. Normalized and raw variables are not considered as correlated in the plot.<br><br>The plots can take a few minutes to load!<br><br>"
                                ),
                                htmlOutput("correlated_variables") %>%
                                  withSpinner(type = 6, color = "#cf395c")
                              )
                            )
                          ),
                          tabPanel(
                            "About the samples", HTML(
                              "<br>Here you can see information about the samples that are present on the selection set.<br><br>Remember you can have included (reconstructed) germline sequences!"
                            ),
                            uiOutput("about_samples")
                          ),
                          tabPanel(
                            "Add covariables", HTML("<br>Here you can add covariables to the selection dataset!<br><br>"),
                            uiOutput("about_meh"),
                            bs4Dash::tabBox(id = "covarmenu", width=12, collapsible = F,
                              tabPanel(
                                "Numerical covariables (e.g. gene expression)", HTML(
                                  "Use column names to define the sequence ID (column name Sequence_ID) and the covariables (use your own nomenclature)<br>"
                                ),
                                fileInput(
                                  "numerical_covariable_file", "Upload", multiple = F,
                                  accept = c(".tab", ".csv", ".txt")
                                ),
                                uiOutput("numerical_covariables_plot")
                              ),
                              tabPanel(
                                "Categorical covariables (e.g. your own clone IDs or new groupings)",
                                HTML(
                                  "Use column names to define the sequence ID (column name Sequence_ID) and the covariables (use your own nomenclature)<br>"
                                ),
                                fileInput(
                                  "categorical_covariable_file", "Upload", multiple = F,
                                  accept = c(".tab", ".csv", ".txt")
                                )
                              )
                            )
                          )
                        )
                      ),
                      # 4.Feature exploration ######
                      tabPanel(
                        "4.Feature exploration", wellPanel(
                          HTML("<br></br>"),
                          HTML(
                            "Here you can see several Antibody features per region and per group (e.g. see where the NGly sites are, see the number of mutations over the whole sequence, etc.)"
                          ),
                          selectizeInput(
                            inputId="plot_feature", label = NULL, choices = c(NULL),
                            selected = NULL
                          ),
                          uiOutput("Group_selection_for_feature"),
                          materialSwitch(
                            inputId="show_reconstructed",
                            label = "Include reconstructed sequences",
                            value = FALSE, width = NULL, status = "primary"
                          ),
                          materialSwitch(
                            inputId="hide_points",
                            label = "Hide non-selected data points",
                            value = TRUE,
                            width = NULL, status = "primary"
                          ),
                          plotlyOutput("Violin_feature_plot")%>%
                            withSpinner(type = 6, color = "#cf395c"),
                          textAreaInput("user_4_comments",
                                        "User comments",
                                        "",
                                        width = "30%")
                        )
                      ),
                      # 5.Clonal exploration ######
                      tabPanel(
                        "5.Clonal exploration", wellPanel(
                          HTML("<br></br>"),
                          HTML(
                            "Here you can group the sequences per different criteria, see how they behave on each sample and select them so you can mark their subclones in 3."
                          ),
                          hr(), fluidRow(
                            class = "clonal_row", column(
                              6,
                              bs4Dash::tabBox(id = "clonemenu1", width=12, collapsible = F,
                                tabPanel(
                                  "Clonal definition", HTML("<br>"),
                                  uiOutput("clonal_group_output"),
                                  conditionalPanel(
                                    "input.clonal_group != ''",
                                    numericInput(
                                      inputId="dominance_threshold",
                                      label = tags$span("Dominance threshold (%)",
                                                        shinyBS::bsButton("info_dominance_threshold",
                                                                          label = "",
                                                                          icon = icon("info"),
                                                                          style = "info",
                                                                          size = "extra-small")
                                      ),
                                      0.5, min = 0, max = 100
                                    ),
                                    shinyBS::bsPopover(
                                      id = "info_dominance_threshold",
                                      title = "More information",
                                      content = "Relative frequency cut-off to determinate which clones are (non)-dominant.",
                                      placement = "right",
                                      trigger = "click",
                                      options = list(container = "body")
                                    ),
                                    numericInput(
                                      inputId="filter_clonal_group",
                                      label = tags$span("Do not plot clones with a frequency lower than (TO BE IMPLEMENTED)",
                                                        shinyBS::bsButton("info_filter_clonal_group",
                                                                          label = "",
                                                                          icon = icon("info"),
                                                                          style = "info",
                                                                          size = "extra-small")
                                      ),
                                      0, min = 0, max = 100
                                    ),
                                    shinyBS::bsPopover(
                                      id = "filter_clonal_group",
                                      title = "More information",
                                      content = "Hide low-frequency clones to reduce loading times.",
                                      placement = "right",
                                      trigger = "click",
                                      options = list(container = "body")
                                    ),
                                    textAreaInput("user_5_comments",
                                                  "User comments",
                                                  "",
                                                  width = "30%")
                                  )
                                ),
                                tabPanel(
                                  "Calculate new clonal definition", HTML("<br>"),
                                  selectizeInput(
                                    inputId="new_clonal_group",
                                    label = tags$span("Using base definition",
                                                      shinyBS::bsButton("info_new_clonal_group",
                                                                        label = "",
                                                                        icon = icon("info"),
                                                                        style = "info",
                                                                        size = "extra-small")
                                    ),
                                    choices = c("VCDR3J", "Reconstructed germline"),
                                    selected = c("VCDR3J"),
                                    multiple = F, options = list(plugins = list("remove_button"))
                                  ),
                                  shinyBS::bsPopover(
                                    id = "info_new_clonal_group",
                                    title = "More information",
                                    content = "Definition to calculate clones. Either by same V-J combination + CDR3 length + similarity or by same VJ combination + same reconstructed germline.",
                                    placement = "right",
                                    trigger = "click",
                                    options = list(container = "body")
                                  ),
                                  numericInput(
                                    inputId="identity_clonal_group",
                                    label ="with a % identity of  (TO BE IMPLEMENTED)",
                                    100, min = 50, max = 100
                                  ),

                                  selectizeInput(
                                    inputId="clonal_region_group",
                                    label = "in the region(s)  (TO BE IMPLEMENTED)",
                                    choices = c(
                                      "Whole", "FWR1", "CDR1", "FWR2", "CDR2", "FWR3",
                                      "CDR3", "FWR4"
                                    ),
                                    selected = c("CDR3"),
                                    multiple = F, options = list(plugins = list("remove_button"))
                                  ),
                                  selectizeInput(
                                    inputId="clonal_level_group",
                                    label ="at the sequence level of ",
                                    choices = c("AA", "NT"),
                                    selected = c("AA"),
                                    multiple = F, options = list(plugins = list("remove_button"))
                                  ),
                                  materialSwitch(
                                    inputId="calculate_shared_clones",
                                    label ="Contemplate also the possibility of shared clones between samples",
                                    value = FALSE, width = NULL, status = "primary"
                                  ),
                                  actionButton("calculate_new_clone", "Calculate clonal definition")
                                )
                              ),
                              HTML("<br><br>")
                            )
                          ),
                          plotlyOutput("Violin_plot")%>%
                            withSpinner(type = 6, color = "#cf395c"),
                          bs4Dash::tabBox(id = "clonemenu2", width=12, collapsible = F,
                            tabPanel(
                              "Shared clones", HTML("<br><br>"),
                              upsetjs::upsetjsOutput("upset_plot")%>%
                                withSpinner(type = 6, color = "#cf395c"),
                              HTML("<br>"),
                              hr(), HTML(
                                "Here you can see every sample included in the selected comparison in the UpSet plot, one by one"
                              ),
                              HTML("<br>"),
                              plotlyOutput("Comparison_plot")%>%
                                withSpinner(type = 6, color = "#cf395c")
                            ),
                            tabPanel("Clonal diversity"),
                            tabPanel("Clonal VDJ usage"),
                            tabPanel("Subclonal diversity and networks"),
                            tabPanel("Phylogenies")
                          )
                        )
                      ),
                      # Help ######
                      tabPanel(
                        "Help", wellPanel(

                          HTML(
                            "Welcome to AbSolution. The programme runs in different steps, each on a tab. For each step, this Help section will indicate what to do."
                          ),
                          # verbatimTextOutput("code"),
                          h3("About the current step"),
                          uiOutput("HELP_output"),
                          h3("Options"),


                          h3("Do you want to start from scratch?"),
                          actionButton(
                            "Reset_all", "Reload AbSolution", icon("rotate-left"),
                            style = "color: #fff; background-color: #18bc9c"
                          ),
                          h3("TO REMOVE IN THE FUTURE:"),
                          HTML(
                            "<br>do a good help guide here and check how they did the documentation for immuneML, write down strenghts and points of improvement, let download the data behind a figure, maybe work in reproducibility</br>"
                          ),

                          img(
                            src = "www/img/AbSolution_scheme.png", height = "100%",
                            width = "100%"
                          )



                        )
                      )
                  )
                  ),
                tabItem(
                  tabName = "About", bs4Dash::userBox(
                    title = userDescription(
                      title = "   Bioinformatics Laboratory", subtitle = "   Amsterdam UMC – location AMC",
                      image = "www/img/BioinformaticsLaboratory.png", type = 2
                    ),
                    status = "orange", width = 12, closable = F, footer = HTML(
                      "<p align='justify'>
                                  The Bioinformatics Laboratory was initiated in 1997 to strengthen biomedical research in the Academic Medical Center (AMC, Amsterdam). The laboratory is part of the department of Clinical Epidemiology, Biostatistics and Bioinformatics (CEBB) and is headed by Antoine van Kampen. The bioinformatics group members represent a broad range of bioinformatics, statistics, and (systems) biology expertise. They engage in research and support projects, and significantly contribute to various education and training programmes.
                                  <br><br>
                                  Our research focuses on the bioinformatics analysis of single-cell (RNAseq) data, the reconstruction of gene networks, and the computational modelling of biological systems. Research is strongly focussed on immunology.
                                  </p>"
                    ),
                    shiny::actionButton(
                      inputId = "github_visit", icon = icon("github"),
                      label = "GitHub", value = "Open pop-up", onclick = "window.open('https://github.com/EDS-Bioinformatics-Laboratory/','_blank')"
                    )
                  )
                )
                )
          ),
          controlbar = bs4Dash::dashboardControlbar(
            id = "controlbar",
            collapsed = T,
            overlay = F,
            skin="dark",
            width=300,
            controlbarMenu(
              id = "controlbarmenu",
              controlbarItem(
                title = "Main parameters",
                column(
                  width = 12,
                  align = "left",
                  numericInput(inputId="seed",
                               label = "Set random seed",
                               value = 1234,
                               min=1,
                               max=9999,
                               width="100%"),
                  verbatimTextOutput("onlynumbers"),
                  materialSwitch(
                    "colorblind_mode", "Use colorblind-friendly palettes",
                    value = F, width = NULL, status = "primary"
                  )
                )
              ),
              controlbarItem(
                "Export",
                materialSwitch(
                  "include_data_report", "Include Data files",
                  value = F, width = NULL, status = "primary"
                ),
                materialSwitch(
                  "include_docker_renv", "Export package with renv file",
                  value = F, width = NULL, status = "primary"
                ),
                uiOutput("export_cond")
              )
            )

          ),
          footer=dashboardFooter(
            left = a(
              href = "https://www.linkedin.com/in/rodrigogarciavaliente/",
              target = "_blank", "@RGarciaValiente"
            ),
            right = "2024, version 0.9"
          )

        )
    )
}

#' Add external Resources to the Application
#'
#' This function is internally used to add external
#' resources inside the Shiny application.
#'
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function() {
    add_resource_path("www", app_sys("app/www"))

    #https://github.com/ThinkR-open/golem/issues/297
    add_resource_path(
      "sbs", system.file("www", package = "shinyBS")
    )
    tags$head(
        favicon(), bundle_resources(
            path = app_sys("app/www"),
            app_title = "AbSolution"
        )
    )
}


#' Prepare AbSolution logo
#'
#' This function is internally used to prepare the AbSolution logo
#'
#' @import dashboardthemes
#' @noRd
logo_absolution <- dashboardthemes::shinyDashboardLogoDIY(
    boldText = "Ab", mainText = "Solution", textSize = 16, badgeText = "BETA", badgeTextColor = "white",
    badgeTextSize = 2, badgeBackColor = "#cf395c", badgeBorderRadius = 3
)
