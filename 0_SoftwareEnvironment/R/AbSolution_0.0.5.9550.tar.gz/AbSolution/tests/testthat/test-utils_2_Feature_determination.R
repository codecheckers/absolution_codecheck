## TESTS: translate_fun #####

test_that("Basic translation works and prioritizes first ORF, AAA-> K", {
  expect_equal(translate_fun("AAAT")[[1]], "K")
  expect_equal(translate_fun("AAAT")[[2]], 1)
})

test_that("Basic translation works and skips stop-codons if possible, TAAA-> K", {
  expect_equal(translate_fun("TAAA")[[1]], "K")
  expect_equal(translate_fun("TAAA")[[2]], 2)
})

##THINK if this can be an issue
test_that("Basic translation works and skips stop-codons if possible, TATAA-> Y", {
  expect_equal(translate_fun("TATAA")[[1]], "Y")
  expect_equal(translate_fun("TATAA")[[2]], 1)
})

test_that("Gives back empty AAs, A-> ", {
  expect_equal(translate_fun("A")[[1]], "")
  expect_equal(translate_fun("A")[[2]], "")
})

##THINK if this can be an issue
test_that("Gives back empty AAs, TAA-> ", {
  expect_equal(translate_fun("TAA")[[1]], "")
  expect_equal(translate_fun("TAA")[[2]], "")
})
